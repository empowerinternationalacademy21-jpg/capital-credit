# Capital Credit — Uganda Financial Health MVP

A Next.js + TypeScript + PostgreSQL/Prisma MVP for the Capital Credit concept.

## Demo
Email: `demo@capitalcredit.ug`
Password: `demo1234`

The product uses demo/sample financial activity. It is not a CRB score, lender decision, or loan-approval prediction.

## Run
Requirements: Node.js 20+ and PostgreSQL.

1. Copy `.env.example` to `.env`.
2. Set `DATABASE_URL` and a strong `AUTH_SECRET`.
3. `npm install`
4. `npm run db:push`
5. `npm run db:seed`
6. `npm run dev`
7. Open `http://localhost:3000`.

## Included
Landing page, authentication, onboarding, transparent score engine, dashboard, score breakdown, demo activity, insights, actions, borrowing readiness, goals, profile/privacy screen, admin metrics, PostgreSQL schema, seed data, provider interfaces, and score tests.

## Score
30% Income Stability + 25% Repayment Behavior + 25% Debt Management + 20% Savings & Cash Buffer.

The scoring module is isolated in `src/lib/score.ts` so a validated model can replace it later.

## Future provider boundaries
`MobileMoneyProvider`, `BankProvider`, `CreditBureauProvider`, and `LenderProvider` are defined in `src/lib/providers.ts`. The MVP uses mock providers and does not claim real integrations.

## Before production
Add formal Uganda-reviewed privacy/terms, consent/audit logging, OTP recovery, rate limiting, authorization/roles, encryption and security review, authorized provider contracts/APIs, regulatory/legal review, analytics, accessibility testing, real notification delivery, migrations/backups/monitoring, and a validated scoring model.
