import { PrismaClient, TransactionType, EmploymentStatus, BorrowFrequency } from "@prisma/client";
import bcrypt from "bcryptjs";
const prisma = new PrismaClient();

async function main() {
  const passwordHash = await bcrypt.hash("demo1234", 12);
  const user = await prisma.user.upsert({
    where: { email: "demo@capitalcredit.ug" },
    update: {},
    create: {
      firstName: "Sarah", email: "demo@capitalcredit.ug", phone: "+256700000001",
      passwordHash, ageRange: "25-34", employmentStatus: EmploymentStatus.EMPLOYED,
      income: 2400000, incomeSource: "Salary", expenses: 1650000, savings: 300000,
      existingLoans: 1200000, monthlyRepayments: 250000,
      borrowFrequency: BorrowFrequency.OCCASIONALLY, goal: "Increase my loan eligibility", score: 72
    }
  });
  await prisma.transaction.deleteMany({where:{userId:user.id}});
  await prisma.scoreHistory.deleteMany({where:{userId:user.id}});
  await prisma.goal.deleteMany({where:{userId:user.id}});
  await prisma.notification.deleteMany({where:{userId:user.id}});
  const months=["Apr","May","Jun","Jul","Aug","Sep"], scores=[65,67,68,70,66,72];
  await prisma.scoreHistory.createMany({data:months.map((month,i)=>({userId:user.id,month,score:scores[i]}))});
  const now=new Date();
  const rows=[
    ["Salary","Salary",1500000,TransactionType.INCOME],
    ["Mobile Money Transfer","Transfer",100000,TransactionType.SPENDING],
    ["Airtime","Airtime",20000,TransactionType.SPENDING],
    ["Groceries","Groceries",85000,TransactionType.SPENDING],
    ["Transport","Transport",40000,TransactionType.SPENDING],
    ["Loan Repayment","Loan",150000,TransactionType.LOAN],
    ["Savings","Savings",100000,TransactionType.SAVINGS],
    ["Salary","Salary",900000,TransactionType.INCOME],
    ["Loan Repayment","Loan",100000,TransactionType.LOAN],
    ["Savings","Savings",200000,TransactionType.SAVINGS]
  ];
  await prisma.transaction.createMany({data:rows.map((r,i)=>({
    userId:user.id,label:r[0] as string,category:r[1] as string,amount:r[2] as number,
    type:r[3] as TransactionType,date:new Date(now.getTime()-i*2*86400000)
  }))});
  await prisma.goal.create({data:{
    userId:user.id,title:"Prepare for a UGX 500,000 loan",target:500000,current:340000,targetScore:80,
    actions:["Build a larger cash buffer","Maintain consistent savings","Reduce repayment pressure"]
  }});
  await prisma.notification.createMany({data:[
    {userId:user.id,title:"Score update",body:"Your financial health score increased by 4 points."},
    {userId:user.id,title:"Savings habit",body:"You've saved money in 4 of the last 6 months."},
    {userId:user.id,title:"Spending alert",body:"Your monthly expenses increased."}
  ]});
}
main().finally(()=>prisma.$disconnect());
