import{NextResponse}from"next/server";import{getSessionUserId}from"@/lib/auth";import{prisma}from"@/lib/prisma";
export async function GET(){const id=await getSessionUserId();if(!id)return NextResponse.json({error:"Unauthorized"},{status:401});return NextResponse.json(await prisma.transaction.findMany({where:{userId:id},orderBy:{date:"desc"}}));}
