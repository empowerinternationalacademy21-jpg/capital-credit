import "./globals.css";
export const metadata={title:"Capital Credit",description:"Financial health for Uganda"};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
