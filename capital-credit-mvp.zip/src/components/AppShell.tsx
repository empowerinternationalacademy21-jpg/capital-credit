import Nav from "./Nav";
export default function AppShell({children}:{children:React.ReactNode}){return <><Nav/><main className="content" style={{marginLeft:240,padding:28,maxWidth:1250}}>{children}</main></>}
