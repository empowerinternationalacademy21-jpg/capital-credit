import {SignJWT,jwtVerify} from "jose"; import {cookies} from "next/headers";
const secret=new TextEncoder().encode(process.env.AUTH_SECRET||"dev-only-secret-change-me");
export async function createSession(userId:string){const token=await new SignJWT({userId}).setProtectedHeader({alg:"HS256"}).setIssuedAt().setExpirationTime("7d").sign(secret);(await cookies()).set("cc_session",token,{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",path:"/"});}
export async function getSessionUserId(){const token=(await cookies()).get("cc_session")?.value;if(!token)return null;try{const {payload}=await jwtVerify(token,secret);return typeof payload.userId==="string"?payload.userId:null;}catch{return null;}}
export async function clearSession(){(await cookies()).delete("cc_session");}
