import {FinancialInput} from "./score";
export function buildInsights(x:FinancialInput){
 const out:any[]=[];
 if(x.income>0&&x.expenses/x.income<.75)out.push({title:"Your income has room",body:"Your current expenses are below your estimated income, giving you some room to build a stronger buffer."});
 if(x.monthlyRepayments>x.income*.10)out.push({title:"Your loan repayments increased",body:"Loan repayments represent a meaningful share of your estimated monthly income."});
 if(x.savings>0)out.push({title:"You're building a savings habit",body:"Keeping savings consistent can strengthen your financial resilience."});
 return out.length?out:[{title:"Start building your financial picture",body:"Adding accurate income, expense and savings information will make your profile more useful."}];
}
export function buildActions(x:FinancialInput){
 const out:any[]=[];
 if(x.savings<x.expenses*.5)out.push({title:"Build a larger cash buffer",body:"Try setting aside UGX 20,000 per week.",impact:4});
 if(x.income>0&&x.monthlyRepayments/x.income>.10)out.push({title:"Reduce repayment pressure",body:"Your estimated monthly repayments are relatively high compared with your income.",impact:5});
 out.push({title:"Maintain consistent savings",body:"Regular saving can make your financial position more resilient.",impact:3});
 return out.slice(0,3);
}
