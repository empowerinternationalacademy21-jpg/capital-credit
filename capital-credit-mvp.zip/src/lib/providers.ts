export interface MobileMoneyProvider{getTransactions(userRef:string,from:Date,to:Date):Promise<any[]>}
export interface BankProvider{getTransactions(userRef:string,from:Date,to:Date):Promise<any[]>}
export interface CreditBureauProvider{getConsumerProfile(userRef:string):Promise<unknown>}
export interface LenderProvider{getBorrowingOptions(userRef:string):Promise<unknown>}
export class MockMobileMoneyProvider implements MobileMoneyProvider{async getTransactions(){return[]}}
export class MockCreditDataProvider implements CreditBureauProvider{async getConsumerProfile(){return{source:"mock",connected:false}}}
