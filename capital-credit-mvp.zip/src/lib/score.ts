export type FinancialInput={income:number;expenses:number;savings:number;existingLoans:number;monthlyRepayments:number;borrowFrequency?:string|null};
export type ScoreBreakdown={incomeStability:number;repaymentBehavior:number;debtManagement:number;savingsBuffer:number;total:number};
const clamp=(n:number)=>Math.max(0,Math.min(100,Math.round(n)));
export function calculateScore(x:FinancialInput):ScoreBreakdown{
 const incomeStability=clamp(x.income>0?70+Math.min(25,Math.max(0,(x.income-x.expenses)/x.income*30)):20);
 const repaymentBehavior=clamp(88-(x.borrowFrequency==="FREQUENTLY"?12:x.borrowFrequency==="OCCASIONALLY"?3:0));
 const repaymentRatio=x.income>0?x.monthlyRepayments/x.income:1;
 const debtManagement=clamp(92-repaymentRatio*100-(x.existingLoans>x.income?10:0));
 const bufferMonths=x.expenses>0?x.savings/x.expenses:0;
 const savingsBuffer=clamp(45+bufferMonths*35);
 const total=clamp(incomeStability*.30+repaymentBehavior*.25+debtManagement*.25+savingsBuffer*.20);
 return {incomeStability,repaymentBehavior,debtManagement,savingsBuffer,total};
}
export function scoreStatus(score:number){if(score>=80)return"Excellent";if(score>=65)return"Good";if(score>=50)return"Fair";return"Needs attention";}
